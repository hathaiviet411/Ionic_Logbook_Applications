export interface Student {
  id?: number,
  name: string,
  country: string,
  languages: string[],
  gender: string,
  dateOfBirth: string,
};